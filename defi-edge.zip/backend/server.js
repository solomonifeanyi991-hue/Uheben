// Express backend for Defi-Edge
const express = require('express');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');

const app = express();
const db = new sqlite3.Database(':memory:');

app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));

// Create table
db.serialize(()=>{
  db.run("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT, password TEXT, wallet_address TEXT, balance REAL DEFAULT 0)");
});

// Signup
app.post('/api/signup',(req,res)=>{
  const {email,password}=req.body;
  db.run("INSERT INTO users (email,password) VALUES (?,?)",[email,password],function(err){
    if(err) return res.status(400).json({error:err.message});
    res.json({id:this.lastID,email});
  });
});

// Login
app.post('/api/login',(req,res)=>{
  const {email,password}=req.body;
  db.get("SELECT * FROM users WHERE email=? AND password=?",[email,password],(err,row)=>{
    if(err||!row) return res.status(401).json({error:"Invalid"});
    res.json({id:row.id,email:row.email});
  });
});

// Admin list
app.get('/api/admin/users',(req,res)=>{
  db.all("SELECT id,email,wallet_address,balance FROM users",(err,rows)=>{
    if(err) return res.status(500).json({error:"DB error"});
    res.json({users:rows});
  });
});

// Update wallet
app.put('/api/admin/user/:id/wallet',(req,res)=>{
  const {wallet_address}=req.body;
  db.run("UPDATE users SET wallet_address=? WHERE id=?",[wallet_address,req.params.id],function(err){
    if(err) return res.status(500).json({error:"DB error"});
    res.json({updated:this.changes});
  });
});

// Update balance
app.put('/api/admin/user/:id/balance',(req,res)=>{
  const {balance}=req.body;
  db.run("UPDATE users SET balance=? WHERE id=?",[balance,req.params.id],function(err){
    if(err) return res.status(500).json({error:"DB error"});
    res.json({updated:this.changes});
  });
});

app.listen(4000,()=>console.log("Server running on http://localhost:4000"));
