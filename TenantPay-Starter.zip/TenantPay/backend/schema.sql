CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  full_name VARCHAR(255),
  email VARCHAR(255) UNIQUE,
  phone VARCHAR(20),
  password TEXT,
  role VARCHAR(20),
  apartment_number VARCHAR(50),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE bills (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  bill_type VARCHAR(100),
  amount DECIMAL,
  status VARCHAR(20) DEFAULT 'unpaid',
  due_date DATE
);

CREATE TABLE payments (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  bill_id INTEGER REFERENCES bills(id),
  amount DECIMAL,
  payment_reference VARCHAR(255),
  status VARCHAR(20),
  paid_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);