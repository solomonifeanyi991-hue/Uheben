const express = require('express');
const cors = require('cors');

const app = express();

app.use(cors());
app.use(express.json());

app.get('/', (req, res) => {
  res.json({ message: 'TenantPay API Running' });
});

app.post('/api/auth/login', (req, res) => {
  res.json({
    token: 'sample-jwt-token',
    role: 'tenant'
  });
});

app.listen(5000, () => {
  console.log('Server running on port 5000');
});