# TenantPay

TenantPay is a modern tenant billing and payment platform for landlords in Nigeria.

## Features
- Tenant login
- Admin login
- Bill management
- Paystack integration
- Automatic receipt generation
- Email receipts
- Manual and automatic billing

## Stack
- Frontend: Next.js + Tailwind CSS
- Backend: Node.js + Express
- Database: PostgreSQL

## Deploy
Frontend:
- Vercel

Backend:
- Railway

Database:
- PostgreSQL

## Quick Start

### Frontend
```bash
cd frontend
npm install
npm run dev
```

### Backend
```bash
cd backend
npm install
npm run dev
```