export default function Home() {
  return (
    <main className="min-h-screen bg-gray-100 p-10">
      <h1 className="text-5xl font-bold">TenantPay</h1>
      <p className="mt-4 text-lg">
        Smart tenant billing and payment platform.
      </p>

      <div className="mt-10 flex gap-4">
        <button className="bg-black text-white px-5 py-3 rounded-xl">
          Tenant Login
        </button>

        <button className="border px-5 py-3 rounded-xl">
          Landlord Login
        </button>
      </div>
    </main>
  );
}